文件清单：
./src/input下：
1.programe.txt            输入文件（待分析程序）
2.grammar.txt             输入文件（语法规则）
./src/output下：
3.main_table.txt          词法分析结果（主表）
4.id_table.txt            词法分析结果（标识符表）
5.number_table.txt        词法分析结果（数字表）
6.twox.txt                词法分析结果（三元式）
7.FIRST.txt               语法分析结果（FIRST集）
8.FOLLOW.txt              语法分析结果（FOLLOW集）
9.SELECT.txt              语法分析结果（SELECT集）
10.pre_list.txt           语法分析结果（分析表）
11.process.txt            语法分析结果（语法分析过程）
12.four_exp.txt           中间代码（四元式）
13.assemble.txt           目标代码（汇编语言）
14.struct.h               程序总体数据结构
./src下：
15.word_analysis.h        词法分析
16.grammar_analysis.h     语法分析
17.translation.h          中间代码、目标代码生成
18.main.cpp               主程序
19.main.exe               执行文件
20.README.txt             帮助文件

./doc 存放实验报告的.md版本和.pdf版本
./img 存放实验报告中涉及到的图片资源和draw.io资源
./src 存放实验代码以及输入输出文件

程序使用：
在programe.txt中输入待分析程序，双击可执行文件（main.exe）即可输出结果（以文件形式输出）
